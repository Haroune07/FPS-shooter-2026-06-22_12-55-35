using UnityEngine;

public class JumpState : State<PlayerController>
{
    int counter;
    public JumpState(PlayerController ctx, StateFactory<PlayerController> factory) : base(ctx, factory)
    {
    }

    public override void Enter()
    {
        Debug.Log($"enter Jump State {counter++}");
        // apply instant jumping force
        ctx.Rb.AddForce(Vector3.up * ctx.Stats.jumpForce, ForceMode.Impulse);
    }

    public override void FixedUpdate(float fixedDeltaTime)
    {
        if(ctx.Rb.linearVelocity.y < ctx.Stats.yVelFallThreshold)
        {
            TransitionSelf(stateFactory.Get<FallingState>());
        }
    }

    public override void Exit()
    {
        counter = 0;
    }
}